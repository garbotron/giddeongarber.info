<?php

include_once("simple_html_dom.php");

// Turn off "magic quotes" (from http://php.net/manual/en/security.magicquotes.disabling.php)
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else {
                $process[$key][stripslashes($k)] = stripslashes($v);
            }
        }
    }
    unset($process);
}

define("BASIC_LANDS", serialize(array("Plains", "Island", "Swamp", "Mountain", "Forest")));

main();

function main() {
  $input = $_POST["input"];
  list($cleansedDecklist, $prices) = calculate($input);
  setcookie("input", base64_encode($cleansedDecklist));
  setcookie("output", base64_encode($prices));
  header("Location: http://www.giddeongarber.info/mtg/index.php");
}

function isWhitespace($str) {
  return (ctype_space($str) || (ord($str) == 160));
}

function trimAll($str) {
  // PHP is bad at non-breaking spaces
  $len = strlen($str);
  $first = 0;
  $last = $len - 1;

  while (($first < $len) && isWhitespace($str[$first])) {
    $first++;
  }

  if ($first == $len) {
    return "";
  }

  while (($last >= 0) && isWhitespace($str[$last])) {
    $last--;
  }

  return substr($str, $first, ($last - $first) + 1);
}

function calculate($decklist) {
  $basicLands = unserialize(BASIC_LANDS);

  $cards = parseDecklist($decklist);
  if (is_string($cards)) {
    return array($decklist, $cards);
  }

  foreach ($cards as $card) {

    gc_collect_cycles();

    $freeCard = NULL;
    foreach ($basicLands as $basicLand) {
      if (strcasecmp($basicLand, $card->name) == 0) {
        $freeCard = $basicLand;
        break;
      }
    }

    if (is_null($freeCard)) {
      $card->fetchInfo();
      if (isset($card->error)) {
        return array($decklist, $card->error);
      }
    } else {
      $card->name = $freeCard;
      $card->set = "Basic Land";
      $card->price = 0;
    }
  }

  // Re-write the input, sanitized
  $sanitized = "";
  foreach ($cards as $card) {
    $sanitized .= sprintf("%dx %s\n", $card->count, $card->name);
  }

  // Write the output
  $totalCount = 0;
  $totalPrice = 0;
  foreach ($cards as $card) {
    $totalCount += $card->count;
    $totalPrice += $card->count * $card->price;
  }
  $prices = sprintf("Total: %d cards - $%0.2f\n", $totalCount, $totalPrice);
  foreach ($cards as $card) {
    $prices .= sprintf("%s [%s]: %dx $%0.2f\n", $card->name, $card->set, $card->count, $card->price);
  }

  return array($sanitized, $prices);
}

function parseDecklist($decklist) {
  $cards = array();
  foreach (preg_split("/\r\n|\n|\r/", $decklist) as $line) {
    $line = trimAll($line);
    if (empty($line)) {
      continue;
    }

    $numEnd = 0;
    while (is_numeric($line[$numEnd])) {
      $numEnd++;
    }

    if ($numEnd == 0) {
      return sprintf("Invalid format: '%s'", $line);
    }

    $nameStart = $numEnd;
    if (($line[$nameStart] == "x") || ($line[$nameStart] == "X")) {
      ++$nameStart;
    }

    $count = substr($line, 0, $numEnd);
    $name = trimAll(substr($line, $nameStart));
    $cards[] = new CardEntry($name, $count);
  }

  return $cards;
}

class CardEntry {
  var $name;
  var $count;
  var $price;
  var $set;
  var $error;

  function __construct($name, $count) {
    $this->name = $name;
    $this->count = $count;
  }

  function fetchInfo() {
    $html = file_get_html("http://magic.tcgplayer.com/db/search_result.asp?Name=" . urlencode($this->name));

    // We're going to use some serious vodoo here.  If it redirected us to a single page, that mage will contain the
    // an H1 element with the name of the card.  If we weren't redirected, it will contain a table of prices(the page
    // is formatted completely differently).

    $headers = $html->find("h1");
    if (!empty($headers)) {
      $this->name = $headers[0]->plaintext;
      $this->price = $this->fetchMedianPriceFromSinglePage($html);
      $this->set = $this->fetchSetFromSinglePage($html);
      return;
    }

    $name = $this->name;
    $price = null;
    $set = null;

    foreach ($html->find("a") as $a) {
      if (strcasecmp(trimAll(html_entity_decode($a->plaintext)), trimAll($this->name)) != 0) {
        continue;
      }

      $row = $a;
      while (!is_null($row) && ($row->tag != "tr")) {
        $row = $row->parent();
      }

      if (is_null($row)) {
        continue; // must be an invalid link
      }

      $name = trimAll(html_entity_decode($a->plaintext));
      $cells = $row->find("td");

      $thisPrice = trimAll($cells[5]->plaintext);
      if (preg_match("/^\\$[0-9\\.]+$/", $thisPrice)) {
        $thisPrice = substr($thisPrice, 1);
        if (is_null($price) || ($thisPrice < $price)) {
          $price = $thisPrice;
          $set = trimAll(html_entity_decode($cells[2]->plaintext));
        }
      }
    }

    if (is_null($price)) {
      $this->error = "Couldn't find card: " . $this->name;
      return;
    }

    $this->name = $name;
    $this->price = $price;
    $this->set = $set;
  }

  function fetchMedianPriceFromSinglePage($html) {

    $mCell = null;
    foreach ($html->find("td") as $td) {
      if ($td->plaintext == "M:") {
        $mCell = $td;
        break;
      }
    }

    if (is_null($mCell)) {
      $this->error = "Invalid single result page: " . $this->name;
      return 0;
    }

    $priceCell = $mCell->next_sibling();
    $price = trimAll($priceCell->plaintext);
    if (!empty($price) && ($price[0] == "$")) {
      $price = substr($price, 1);
    }
    return $price;
  }

  function fetchSetFromSinglePage($html) {

    $priceGuideLink = null;
    $prevA = null;
    foreach ($html->find("a") as $a) {
      if ($a->plaintext == "Price Guide") {
        $priceGuideLink = $a;
        break;
      }
      $prevA = $a;
    }

    if (is_null($priceGuideLink) || is_null($prevA)) {
      $this->error = "Couldn't find set on single result page: " . $this->name;
      return null;
    }

    $href = $prevA->href;
    $idx = strpos($href, "Set_Name=");
    $idx += strlen("Set_Name=");
    return substr($href, $idx);
  }
}

?>
