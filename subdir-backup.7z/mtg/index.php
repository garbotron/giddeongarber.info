<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="english">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=UTF-8" />
    <title>MTG Price Check</title>

    <style type="text/css">
      
      * {
        font-size: 10pt;
        font-family: Arial, Helvetica, sans-serif;
      }

      table {
        width: 100%;
      }

      td {
        padding-left: 0.5em;
        padding-right: 0.5em;
      }

      textarea {
        width: 100%;
        height: 30em;
      }

      input[type="submit"] {
        width: 30em;
        height: 3em;
        margin-top: 0.5em;
      }

      td.submit {
        text-align: center;
      }

    </style>

  </head>
  <body>

    <form action="check.php" method="post">
      <table>
        <tr>
          <th>Deck List</th>
          <th>Prices</th>
        </tr>
        <tr>
          <td>
            <textarea name="input" cols="1000" rows="1000"><?php
                if (isset($_COOKIE["input"])) {
                  echo base64_decode($_COOKIE["input"]);
                } else {
              ?>Enter your decklist in the following format:
1x Forest
2x Llanowar Elves

Or:
1 Forest
2 Llanowar Elves<?php } ?></textarea>
          </td>
          <td>
            <textarea name="output" cols="1000" rows="1000" readonly="readonly"><?php
                if (isset($_COOKIE["output"])) {
                  echo base64_decode($_COOKIE["output"]);
                } else {
              ?>Hit "Check Prices" to scan TCGPlayer.<?php } ?></textarea>
          </td>
        </tr>
        <tr>
          <td colspan="2" class="submit">
            <input type="submit" value="Check Prices" />
          </td>
        </tr>
      </table>
    </form>
  
  </body>
</html>