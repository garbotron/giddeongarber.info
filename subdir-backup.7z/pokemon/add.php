<?

require "common.php";

$new_pokemon = new Pokemon($_POST["name"]);

if (empty($new_pokemon->Name)) {
  header("Location: $page_log");
  die();
}

foreach ($collection as $pokemon) {
  if ($pokemon->Name == $new_pokemon->Name) {
    header("Location: $page_log");
    die();
  }
}

$type_a = -1;
$type_b = -1;
for ($i = 0; $i < count($types); $i++) {
  $type_name = $types[$i]->Name;
  if ($_POST["type-$type_name"] == "on") {
    if ($type_a == -1) {
      $type_a = $i;
    } else {
      $type_b = $i;
      break;
    }
  }
}

if ($type_a == -1) {
  $type_a = count($types) - 1;
}

$new_pokemon->Types = array($type_a);
if ($type_b != -1) {
  $new_pokemon->Types[] = $type_b;
}

$collection[] = $new_pokemon;
file_put_contents($db_file, json_encode($collection));

header("Location: $page_log");
die();

?>