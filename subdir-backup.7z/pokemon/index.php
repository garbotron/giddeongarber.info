<? 
require "common.php";
?>

<!DOCTYPE HTML>
<html>
<head>
<title>PokéLog</title>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=0.85">

<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/bootstrap/3.0.3/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/plug-ins/be7019ee387/integration/bootstrap/3/dataTables.bootstrap.css">

<script type="text/javascript" language="javascript" src="//code.jquery.com/jquery-1.10.2.min.js"></script>
<script type="text/javascript" language="javascript" src="//maxcdn.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/1.10.0/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" language="javascript" src="//cdn.datatables.net/plug-ins/be7019ee387/integration/bootstrap/3/dataTables.bootstrap.js"></script>

<style type="text/css">

span.label-type {
  border: 1px solid #333;
  text-shadow: 1px 1px #333;
  text-transform: uppercase;
}

label.btn-type,
label.btn-type:hover,
label.btn-type.active {
  color: white;
  border-color: #333;
  text-shadow: 1px 1px #333;
  text-transform: uppercase;
  font-weight: bold;
  margin-bottom: 0.5em;
}

label.btn-type:hover {
  text-decoration: underline;
}

label.btn-type.active {
  -moz-box-shadow: inset 0 0 16px black;
  -webkit-box-shadow: inset 0 0 16px black;
  box-shadow: inset 0 0 16px black;
}

</style>

<script type="text/javascript">

var types = <?= json_encode($types) ?>;
var collection = <?= json_encode($collection) ?>;

function get_type_elem(idx) {
  return "<span class='label label-type' style='background-color: " + 
    types[idx].Color +
    "'>" +
    types[idx].Name +
    "</span>";
}

function edit_pokemon(name) {
  alert("IT HAPPENED " + name);
}

function remove_pokemon(name) {
  window.location.replace("<?= $page_remove ?>&name=" + name);
}

$(document).ready(function() {
  
  $('#main_table').DataTable( {
    data: collection,
    order: [],
    columns: [

      { data: { 
        _: "Name",
        display: function(row, type, val, meta) {
          return '<div class="dropdown">' +
                 '<a data-toggle="dropdown" title="Click to edit/remove this pokémon" href="#">' + row.Name + '</a>' +
                 '<ul class="dropdown-menu" role="menu">' +
                 '<li><a href="#" onclick=\'edit_pokemon("' + row.Name + '");return false;\'><span class="glyphicon glyphicon-cog"></span> Edit</a></li>' +
                 '<li><a href="#" onclick=\'remove_pokemon("' + row.Name + '");return false;\'><span class="glyphicon glyphicon-remove"></span> Remove</a></li>' +
                 '</ul>' +
                 '</div>';
        }
      } },
      
      { data: {
        _: "Types",
        
        display: function(row, type, val, meta) {
          var html_text = get_type_elem(row.Types[0]);
          if (row.Types.length > 1) {
            html_text += " " + get_type_elem(row.Types[1]);
          }
          return html_text; 
        },
        
        filter: function(row, type, val, meta) {
          var str = types[row.Types[0]].Name;
          if (row.length > 1) {
            str += "/" + types[row.Types[1]].Name;
          }
          return str;
        }
        
      } } ]
  });

});

</script>

</head>
<body style="padding-top: 65px">

<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
  <div class="container">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="<?= $page_log ?>">PokéLog</a>
    </div>
    <div class="collapse navbar-collapse">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?= $page_log ?>">Pokémon Log</a></li>
        <li><a href="<?= $page_chart ?>.php">Type Check</a></li>
      </ul>
    </div>
  </div>
</div>

<div class="container">
  <p>
    <button class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modal-add">Add New Pokémon</button>
  </p>
  <table id="main_table" class="table table-striped table-bordered" cellspacing="0" width="100%">
    <thead>
      <tr>
        <th>Name</th>
        <th>Type(s)</th>
      </tr>
    </thead>
  </table>
</div>

<div class="modal fade" id="modal-add" tabindex="-1" role="dialog" aria-labelledby="modal-add-label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form action="<?= $page_add ?>" method="post">

        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title" id="modal-add-label">Add New Pokémon</h4>
        </div>

        <div class="modal-body">

          <div class="form-group">
            <label for="input-name">Name</label>
            <input type="text" class="form-control" id="input-name" name="name" autocapitalize="on" placeholder="Enter pokémon name">
          </div>

          <div class="form-group">
            <div class="btn-group" data-toggle="buttons">
            <? foreach ($types as $type) { ?>
          
              <label class="btn btn-default btn-type" style="background-color: <?= $type->Color ?>">
                <input type="checkbox" name="type-<?= $type->Name ?>" />
                <?= $type->Name ?>
              </label>
          
            <? } ?>
            </div>
          </div>

        </div>

        <div class="modal-footer">
          <button type="submit" class="btn btn-primary" style="width: 7em">OK</button>
          <button type="button" class="btn btn-default" style="width: 7em" data-dismiss="modal">Cancel</button>
        </div>

      </form>
    </div>
  </div>
</div>

</body>
</html>
