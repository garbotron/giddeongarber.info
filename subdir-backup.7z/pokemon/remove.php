<?

require "common.php";

$to_remove = $_GET["name"];
if (empty($to_remove)) {
  header("Location: $page_log");
  die();
}

for ($i = 0; $i < count($collection); $i++) {
  if ($collection[$i]->Name == $to_remove) {
    unset($collection[$i]);
    file_put_contents($db_file, json_encode($collection));
    break;
  }
}

header("Location: $page_log");
die();

?>