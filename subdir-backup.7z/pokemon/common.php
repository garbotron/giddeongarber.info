<?

class Type {
  public $Name;
  public $Color;
  function Type($name, $color) {
    $this->Name = $name;
    $this->Color = $color;
  }
}

class Pokemon {
  public $Name;
  public $Types;
  function Pokemon($name = "", $types = array(0)) {
    $this->Name = $name;
    $this->Types = $types;
  }
}

$types = array(
  new Type("Normal"  , "#A8A77A"),
  new Type("Flying"  , "#A98FF3"),
  new Type("Fighting", "#C22E28"),
  new Type("Grass"   , "#7AC74C"),
  new Type("Fire"    , "#EE8130"),
  new Type("Water"   , "#6390F0"),
  new Type("Electric", "#F7D02C"),
  new Type("Ice"     , "#96D9D6"),
  new Type("Psychic" , "#F95587"),
  new Type("Bug"     , "#A6B91A"),
  new Type("Poison"  , "#A33EA1"),
  new Type("Ground"  , "#E2BF65"),
  new Type("Rock"    , "#B6A136"),
  new Type("Dark"    , "#705746"),
  new Type("Steel"   , "#B7B7CE"),
  new Type("Dragon"  , "#6F35FC"),
  new Type("Ghost"   , "#735797"),
  new Type("Fairy"   , "#DFA0AB"),
  new Type("???"     , "#A0A0A0")
);

$username = $_GET['username'];
if (!isset($username))
{
    die("YOU FORGOT THE USERNAME YOU FOOL!");
}

/* Saved for use in other scripts */
$page_base = "http://www.giddeongarber.info/pokemon";
$page_log = "$page_base/index.php?username=$username";
$page_chart = "$page_base/chart.php?username=$username";
$page_add = "$page_base/add.php?username=$username";
$page_remove = "$page_base/remove.php?username=$username";

$db_file = "collection-$username.json";

if (file_exists($db_file)) {
  $db_contents = file_get_contents($db_file);
  $collection = json_decode($db_contents);
} else {
  $collection = array();
}

?>
