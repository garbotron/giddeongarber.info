<?
$isAdmin = FALSE;
include("vcommon.php");
?>