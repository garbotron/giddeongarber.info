<?
include("vconnection.php");
$query = "SELECT * FROM pics WHERE suppress = 0 ORDER BY RAND() LIMIT 1";
$result = mysql_query($query);
if (mysql_numrows($result) != 1) {
  die("Query failed");
}
mysql_close();
$id = mysql_result($result, 0, "id");
$game = mysql_result($result, 0, "game");
$system = mysql_result($result, 0, "system");
$pic = mysql_result($result, 0, "pic");

function checkmobile(){
if(isset($_SERVER["HTTP_X_WAP_PROFILE"])) return true;
if(preg_match("/wap\.|\.wap/i",$_SERVER["HTTP_ACCEPT"])) return true;
if(isset($_SERVER["HTTP_USER_AGENT"])){
// Quick Array to kill out matches in the user agent
// that might cause false positives
$badmatches = array("OfficeLiveConnector","MSIE\ 8\.0","OptimizedIE8","MSN\ Optimized","Creative\ AutoUpdate","Swapper");
foreach($badmatches as $badstring){
if(preg_match("/".$badstring."/i",$_SERVER["HTTP_USER_AGENT"])) return false;
}
// Now we'll go for positive matches
$uamatches = array("midp", "j2me", "avantg", "docomo", "novarra", "palmos", "palmsource", "240x320", "opwv", "chtml", "pda", "windows\ ce", "mmp\/", "blackberry", "mib\/", "symbian", "wireless", "nokia", "hand", "mobi", "phone", "cdm", "up\.b", "audio", "SIE\-", "SEC\-", "samsung", "HTC", "mot\-", "mitsu", "sagem", "sony", "alcatel", "lg", "erics", "vx", "NEC", "philips", "mmm", "xx", "panasonic", "sharp", "wap", "sch", "rover", "pocket", "benq", "java", "pt", "pg", "vox", "amoi", "bird", "compal", "kg", "voda", "sany", "kdd", "dbt", "sendo", "sgh", "gradi", "jb", "\d\d\di", "moto","webos");
foreach($uamatches as $uastring){
if(preg_match("/".$uastring."/i",$_SERVER["HTTP_USER_AGENT"])) return true;
}
}
return false;
} 

?>
<html>
<head>
<title>Gamershots: Screenshot Drinking Game</title>
<style type="text/css">
* {
  padding: 0;
  margin: 0;
  width: 100%;
  height: 100%;
}
body {
  background-color: #CCC;
}
#loading {
  position: absolute;
  background-color: #DDD;
  height: 30px;
  line-height: 30px;
  text-align: center;
  font-family: verdana, sans-serif;
  font-size: 20px;
  font-weight: bold;
  border: 1px solid #777;
  width: 70%;
  margin-left: 15%;
  margin-top: 10px;
}
#outer {
  padding: 1px;
  border: 1px solid #021a40;
  background-color: #777;
  position: absolute;
  width: 0;
  height: 0;
  visibility: hidden;
}
#overlay {
  position: absolute;
  bottom: 0px;
  left: 50%;
  width: 500px;
  height: auto;
  margin-left: -225px;
  margin-bottom: 10%;
}
#overlayTopLeft {
  background-image: url("frame_tl.png");
  width: 11px;
  height: 11px;
}
#overlayTopCenter {
  background-image: url("frame_t.png");
  width: auto;
  height: 11px;
}
#overlayTopRight {
  background-image: url("frame_tr.png");
  width: 11px;
  height: 11px;
}
#overlayLeft {
  background-image: url("frame_l.png");
  width: 11px;
  height: auto;
}
#overlayInner {
  background-image: url("frame_inner.png");
  width: auto;
  height: auto;
  text-align: center;
  line-height: 100%;
  font-family: verdana, sans-serif;
  font-size: 20px;
  font-weight: bold;
}
#overlayRight {
  background-image: url("frame_r.png");
  width: 11px;
  height: auto;
}
#overlayBottomLeft {
  background-image: url("frame_bl.png");
  width: 11px;
  height: 11px;
}
#overlayBottomCenter {
  background-image: url("frame_b.png");
  width: auto;
  height: 11px;
}
#overlayBottomRight {
  background-image: url("frame_br.png");
  width: 11px;
  height: 11px;
}
a {
  text-decoration: none;
  color: black;
}
</style>
<script>
var imgAspectRatio = 0;
var image = new Image();
image.src = "<? echo($pic) ?>";
var linkShowingGame = false;
function linkClicked() {
  if (linkShowingGame == true) {
    window.location.href = window.location.href;
  } else {
    var el = document.getElementById("txt");
    el.innerHTML = "<? echo($game) ?> (<? echo($system) ?>)";
    linkShowingGame = true;
  }
}
function keyPressed(e) {
  var evt = window.event ? event : e;
  var code = evt.keyCode ? evt.keyCode : evt.charCode;
  var key = String.fromCharCode(code);
  <?
  if ($isAdmin) { 
  ?>
    if (key == "d") {
      window.location.href = "vsuppress.php?id=<? echo($id) ?>";
    } else if (key == "g") {
      window.location.href = "vsuppress.php?game=<? echo($game) ?>";
    } else if ((code == 13) || (key == " ")) {
      linkClicked();
    }
  <?
  } else {
  ?>
    if ((code == 13) || (key == " ")) {
      linkClicked();
    }
  <?
  }
  ?>
}
function fixSize() {
  if (imgAspectRatio == 0) {
    imgAspectRatio = image.width / image.height;
  }
    
  var loading = document.getElementById("loading");
  loading.style.visibility = "hidden";
  
  var outer = document.getElementById("outer");
  <?
  if (checkmobile()) {
  ?>
    outer.style.width = "auto";
    outer.style.height = "auto";
    var picImg = document.getElementById("pic");
    picImg.style.width = "10000px";
    picImg.style.maxWidth = "100%";
    picImg.style.height = "auto";
  <?
  } else {
  ?>
    var width;
    var height;
    var margin = 50;
    if (((window.innerHeight - margin) * imgAspectRatio) < (window.innerWidth - margin)) {
      height = (window.innerHeight - margin);
      width = height * imgAspectRatio;
    } else {
      width = (window.innerWidth - margin);
      height = width / imgAspectRatio;
    }
    outer.style.width = width;
    outer.style.height = height;
    outer.style.marginLeft = (window.innerWidth - width) / 2;
    outer.style.marginTop = (window.innerHeight - height) / 2;
  <?
  }
  ?>
  outer.style.visibility = "visible";
}
window.captureEvents(Event.RESIZE);  
window.onresize=fixSize;
document.onkeypress=keyPressed;
</script>
</head>
<body id="body" onload="fixSize()">
<a href="javascript:linkClicked();">
<div id="outer">
<img id="pic" src="<? echo($pic) ?>" />
  <div id="overlay">
    <table cellpadding="0" cellspacing="0" style="line-height:0">
    <tr><td id="overlayTopLeft" /><td id="overlayTopCenter" /><td id="overlayTopRight" /></tr><tr><td id="overlayLeft" /><td id="overlayInner">
    <span id="txt">What game is this? Click or hit enter!</span>
    </td><td id="overlayRight" /></tr><tr><td id="overlayBottomLeft" /><td id="overlayBottomCenter" /><td id="overlayBottomRight" /></tr>
    </table>
  </div>
</div>
</a>
<div id="loading">Loading...</div>
</body>
</html>