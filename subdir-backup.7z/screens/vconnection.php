<?
$mysql_host = "mysql4.000webhost.com";
$mysql_database = "a6884914_pics";
$mysql_user = "a6884914_admin";
$mysql_password = "Doodle22";

mysql_connect($mysql_host,$mysql_user,$mysql_password);
@mysql_select_db($mysql_database) or die("Unable to select database");
?>