<?
$isAdmin = TRUE;
include("vcommon.php");
?>