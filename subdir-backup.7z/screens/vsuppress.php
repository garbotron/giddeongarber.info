<?
include("vconnection.php");

$id = $_GET['id'];
$game = $_GET['game'];

$query = "UPDATE pics SET suppress=1 WHERE ";
if ($id) {
  $query .= "id=" . $id;
} else if ($game) {
  $query .= "game='" . $game . "'";
} else {
  die("Must specify id or game!");
}

mysql_query($query);
mysql_close();
?>
<html>
<head>
<title>Gamershots: Supressed</title>
<style type="text/css">
* {
  text-align: center;
  font-family: verdana, sans-serif;
}
</style>
<script>
function keyPressed(e) {
  var evt = window.event ? event : e;
  var code = evt.keyCode ? evt.keyCode : evt.charCode;
  var key = String.fromCharCode(code);
  if ((code == 13) || (key == " ")) {
    window.location.href = "vadmin.php";
  }
}
document.onkeypress=keyPressed;
</script>
</head>
<body>
<h1><? echo($game ? $game : $id) ?> Supressed!</h2>
<h1><a href="vadmin.php">Back to the Game!</a></h2>
</body>
</html>